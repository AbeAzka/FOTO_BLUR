**TUTORIAL**



1. Extract file .zip ini
2. Buka terminal/cmd
3. jalankan perintah ini pip install -r requirements.txt
4. Setelah selesai jalankan ini python blur.py
5. Kalau mau edit buka VSCode

