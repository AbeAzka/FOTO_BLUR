#SOURCE CODE BY: https://github.com/claramiadevira/foto-kita-blur

import cv2
import pygame
import mediapipe as mp

#detect tangan
mp_hands = mp.solutions.hands
pygame.mixer.init()
pygame.mixer.music.load("foto-kita-blur.mp3")

hands = mp_hands.Hands(
    static_image_mode=False,
    max_num_hands=1,
    min_detection_confidence=0.5,
    min_tracking_confidence=0.5
)

def finger_up(tip, pip, landmarks):
    return landmarks[tip].y < landmarks[pip].y


def is_peace(landmarks):

    index_up = finger_up(8, 6, landmarks)
    middle_up = finger_up(12, 10, landmarks)

    ring_up = finger_up(16, 14, landmarks)
    pinky_up = finger_up(20, 18, landmarks)

    return (
        index_up
        and middle_up
        and not ring_up
        and not pinky_up
    )

#open camera
cap = cv2.VideoCapture(0)

while True:

    success, frame = cap.read()

    if not success:
        break

    frame = cv2.flip(frame, 1)

    rgb = cv2.cvtColor(
        frame,
        cv2.COLOR_BGR2RGB
    )

    hand_result = hands.process(rgb)

    peace_detected = False

    if hand_result.multi_hand_landmarks:

        for hand_landmarks in hand_result.multi_hand_landmarks:

            if is_peace(hand_landmarks.landmark):
                peace_detected = True
                break

    #blur efek
    if peace_detected:
        frame = cv2.GaussianBlur(frame, (61, 61), 0)

        if not pygame.mixer.music.get_busy():
            pygame.mixer.music.play(-1)  # -1 = loop while peace sign is held
    else:
        if pygame.mixer.music.get_busy():
            pygame.mixer.music.stop()

    cv2.imshow(
        "Peace Blur",
        frame
    )

    if cv2.waitKey(1) & 0xFF == 27:
        break

cap.release()
cv2.destroyAllWindows()
